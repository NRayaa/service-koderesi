<form action="<?php echo e(route('waybill.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="waybill_id" id=""><br>
    <input type="text" name="courier_code" id=""><br>
    <button type="submit">track</button>
</form>
<?php /**PATH C:\Users\user\Desktop\service-cekresi\cek-resi\resources\views/welcome.blade.php ENDPATH**/ ?>